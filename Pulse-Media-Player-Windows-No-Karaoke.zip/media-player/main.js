const { app, BrowserWindow, ipcMain, dialog, Menu, shell, nativeImage, protocol, net } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const { readMetadata } = require('./metadata');

// Remote audio is streamed through this scheme so the equalizer (Web Audio) can process it.
protocol.registerSchemesAsPrivileged([
  { scheme: 'pulse-remote', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true } },
]);

let mainWindow;
const isDev = process.argv.includes('--dev');

// User data path for persistent library
function getUserDataPath() {
  return path.join(app.getPath('userData'), 'pulse-data.json');
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#0a0a0a',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false, // needed for some media path handling
    },
    show: false,
  });

  mainWindow.loadFile('index.html');

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (isDev) mainWindow.webContents.openDevTools({ mode: 'detach' });
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Open external links in browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

function buildMenu() {
  const template = [
    {
      label: 'File',
      submenu: [
        {
          label: 'Add Files…',
          accelerator: 'CmdOrCtrl+O',
          click: () => mainWindow?.webContents.send('menu-add-files'),
        },
        {
          label: 'Add Folder…',
          accelerator: 'CmdOrCtrl+Shift+O',
          click: () => mainWindow?.webContents.send('menu-add-folder'),
        },
        { type: 'separator' },
        {
          label: 'Clear Library',
          click: () => mainWindow?.webContents.send('menu-clear-library'),
        },
        { type: 'separator' },
        { role: 'quit' },
      ],
    },
    {
      label: 'Playback',
      submenu: [
        {
          label: 'Play / Pause',
          accelerator: 'Space',
          click: () => mainWindow?.webContents.send('menu-toggle-play'),
        },
        {
          label: 'Next',
          accelerator: 'CmdOrCtrl+Right',
          click: () => mainWindow?.webContents.send('menu-next'),
        },
        {
          label: 'Previous',
          accelerator: 'CmdOrCtrl+Left',
          click: () => mainWindow?.webContents.send('menu-prev'),
        },
      ],
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'togglefullscreen' },
      ],
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'About Pulse',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'About Pulse',
              message: 'Pulse Media Player',
              detail: 'Local media player with Apple + Spotify inspired UI.\nVersion 1.0.0',
            });
          },
        },
      ],
    },
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// ========== IPC Handlers ==========

// Open file dialog
ipcMain.handle('dialog:openFiles', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile', 'multiSelections'],
    filters: [
      { name: 'Media', extensions: [
        'mp3', 'wav', 'flac', 'aac', 'ogg', 'm4a', 'opus', 'wma',
        'mp4', 'webm', 'mkv', 'avi', 'mov', 'm4v', 'ogv', 'wmv'
      ]},
      { name: 'Audio', extensions: ['mp3', 'wav', 'flac', 'aac', 'ogg', 'm4a', 'opus', 'wma'] },
      { name: 'Video', extensions: ['mp4', 'webm', 'mkv', 'avi', 'mov', 'm4v', 'ogv', 'wmv'] },
      { name: 'All Files', extensions: ['*'] },
    ],
  });
  if (result.canceled) return [];
  return result.filePaths;
});

// Open folder dialog
ipcMain.handle('dialog:openFolder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory'],
  });
  if (result.canceled) return null;
  return result.filePaths[0];
});

// Recursively scan a folder for media files
ipcMain.handle('fs:scanFolder', async (_event, folderPath) => {
  const mediaExts = new Set([
    '.mp3', '.wav', '.flac', '.aac', '.ogg', '.m4a', '.opus', '.wma',
    '.mp4', '.webm', '.mkv', '.avi', '.mov', '.m4v', '.ogv', '.wmv'
  ]);
  const results = [];

  function walk(dir) {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        // Skip hidden / system folders
        if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;
        walk(full);
      } else if (entry.isFile()) {
        const ext = path.extname(entry.name).toLowerCase();
        if (mediaExts.has(ext)) {
          try {
            const stat = fs.statSync(full);
            results.push({
              path: full,
              name: entry.name,
              size: stat.size,
              mtime: stat.mtimeMs,
            });
          } catch { /* skip unreadable */ }
        }
      }
    }
  }

  walk(folderPath);
  return results;
});

// Read file as ArrayBuffer (for subtitles or small files)
ipcMain.handle('fs:readText', async (_event, filePath) => {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch (err) {
    return null;
  }
});

// Check if file exists
ipcMain.handle('fs:exists', async (_event, filePath) => {
  try {
    return fs.existsSync(filePath);
  } catch {
    return false;
  }
});

// Get file URL for playback
ipcMain.handle('fs:getFileURL', async (_event, filePath) => {
  try {
    if (!fs.existsSync(filePath)) return null;
    return pathToFileURL(filePath).href;
  } catch {
    return null;
  }
});

// Load / save persistent data
ipcMain.handle('data:load', async () => {
  try {
    const p = getUserDataPath();
    if (fs.existsSync(p)) {
      return JSON.parse(fs.readFileSync(p, 'utf8'));
    }
  } catch (err) {
    console.error('Failed to load data:', err);
  }
  return null;
});

ipcMain.handle('data:save', async (_event, data) => {
  try {
    const p = getUserDataPath();
    fs.writeFileSync(p, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Failed to save data:', err);
    return false;
  }
});

// Subtitle file picker
ipcMain.handle('dialog:openSubtitle', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [
      { name: 'Subtitles', extensions: ['srt', 'vtt'] },
      { name: 'All Files', extensions: ['*'] },
    ],
  });
  if (result.canceled) return null;
  return result.filePaths[0];
});


// ========== Metadata, artwork & lyrics ==========
const metaCache = new Map(); // key: path|mtime -> { meta, art: {thumb, full} }

function toDataURL(buf, mime, maxWidth) {
  try {
    const img = nativeImage.createFromBuffer(buf);
    if (!img.isEmpty()) {
      const { width } = img.getSize();
      if (width > maxWidth) {
        return 'data:image/jpeg;base64,' + img.resize({ width: maxWidth, quality: 'good' }).toJPEG(86).toString('base64');
      }
      if (buf.length < 1.5 * 1024 * 1024) return `data:${mime};base64,${buf.toString('base64')}`;
      return 'data:image/jpeg;base64,' + img.toJPEG(86).toString('base64');
    }
  } catch { /* fall through */ }
  // nativeImage could not decode it; hand the raw bytes to the renderer
  return `data:${mime};base64,${buf.toString('base64')}`;
}

ipcMain.handle('meta:get', async (_event, filePath, wantFull) => {
  try {
    const mtime = fs.statSync(filePath).mtimeMs;
    const key = filePath + '|' + mtime;
    let entry = metaCache.get(key);
    if (!entry) {
      const raw = readMetadata(filePath);
      entry = {
        meta: {
          title: raw.title || null,
          artist: raw.artist || null,
          album: raw.album || null,
          lyrics: raw.lyrics || null,
          lyricsSource: raw.lyricsSource || null,
        },
        raw: raw.art ? { art: raw.art, mime: raw.artMime } : null,
        art: {},
      };
      metaCache.set(key, entry);
      if (metaCache.size > 400) metaCache.delete(metaCache.keys().next().value);
    }
    const out = { ...entry.meta, art: null };
    if (entry.raw) {
      const size = wantFull ? 'full' : 'thumb';
      if (!entry.art[size]) {
        entry.art[size] = toDataURL(entry.raw.art, entry.raw.mime, wantFull ? 900 : 260);
      }
      out.art = entry.art[size];
      // keep raw bytes only for entries that might need a "full" request later
      if (entry.art.thumb && entry.art.full) entry.raw = null;
    }
    return out;
  } catch (err) {
    return { title: null, artist: null, album: null, lyrics: null, lyricsSource: null, art: null };
  }
});

// ========== Online lyrics lookup (LRCLIB: free, no API key) ==========
const LRCLIB = 'https://lrclib.net/api';
const LRCLIB_HEADERS = { 'User-Agent': 'Pulse Media Player v1.1.0 (local desktop player)' };

function normTitle(str) {
  return String(str || '').toLowerCase()
    .replace(/\(.*?\)|\[.*?\]/g, ' ')
    .replace(/\b(feat|ft|featuring)\b.*$/i, ' ')
    .replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

function guessFromFileName(name) {
  let n = String(name || '').replace(/\.[^/.]+$/, '').replace(/_/g, ' ');
  n = n.replace(/^\s*\d{1,3}\s*[-._)]\s*/, '').trim();
  const parts = n.split(/\s+-\s+/);
  if (parts.length >= 2) return { artist: parts[0].trim(), title: parts.slice(1).join(' - ').trim() };
  return { artist: '', title: n };
}

async function lrclibGet(pathAndQuery, state) {
  try {
    const res = await fetch(LRCLIB + pathAndQuery, {
      headers: LRCLIB_HEADERS,
      signal: AbortSignal.timeout(8000),
    });
    state.reachable = true;
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

function usable(r) { return r && (r.syncedLyrics || r.plainLyrics || r.instrumental); }

function durationOk(r, duration, tolerance) {
  if (!duration || !r.duration) return true;
  return Math.abs(r.duration - duration) <= tolerance;
}

function pickBest(results, wantTitle, duration) {
  if (!Array.isArray(results)) return null;
  const nt = normTitle(wantTitle);
  let best = null, bestScore = -1;
  for (const r of results) {
    if (!usable(r)) continue;
    const titleMatch = nt && normTitle(r.trackName) === nt;
    const durKnown = duration && r.duration;
    if (durKnown ? !durationOk(r, duration, 5) : !titleMatch) continue; // avoid showing the wrong song's lyrics
    let score = 0;
    if (titleMatch) score += 4;
    if (durKnown) score += 3 - Math.min(3, Math.abs(r.duration - duration) / 2);
    if (r.syncedLyrics) score += 3;
    if (score > bestScore) { best = r; bestScore = score; }
  }
  return best;
}

ipcMain.handle('lyrics:find', async (_event, q) => {
  const state = { reachable: false };
  const duration = Math.round(Number(q.duration) || 0);
  const fromName = guessFromFileName(q.fileName);
  const title = (q.title || '').trim() || fromName.title;
  const artist = (q.artist || '').trim() || fromName.artist;
  if (!title) return { status: 'notfound' };

  const done = (r) => {
    if (r.instrumental) return { status: 'instrumental' };
    const synced = !!r.syncedLyrics;
    return {
      status: 'found',
      synced,
      lyrics: synced ? r.syncedLyrics : r.plainLyrics,
      matched: [r.artistName, r.trackName].filter(Boolean).join(' - '),
    };
  };
  const qs = (o) => '?' + Object.entries(o).filter(([, v]) => v).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');

  // 1. exact match on artist + title (+ album, duration)
  if (artist) {
    const exact = await lrclibGet('/get' + qs({
      track_name: title, artist_name: artist, album_name: q.album, duration: duration || '',
    }), state);
    if (usable(exact) && durationOk(exact, duration, 5)) return done(exact);
  }

  // 2. search by artist + title, then with decorations like "(feat. X)" removed
  const cleanTitle = title.replace(/\(.*?\)|\[.*?\]/g, ' ').replace(/\s+/g, ' ').trim();
  const attempts = [];
  if (artist) attempts.push(qs({ track_name: title, artist_name: artist }));
  if (artist && cleanTitle && cleanTitle !== title) attempts.push(qs({ track_name: cleanTitle, artist_name: artist }));
  attempts.push(qs({ q: [artist, cleanTitle || title].filter(Boolean).join(' ') }));

  for (const a of attempts) {
    const results = await lrclibGet('/search' + a, state);
    const best = pickBest(results, title, duration) || pickBest(results, cleanTitle, duration);
    if (best) return done(best);
  }
  return { status: state.reachable ? 'notfound' : 'offline' };
});

// ========== Online music search (legal sources only) ==========
// Audius: full-length tracks uploaded by the artists themselves.
// iTunes Search: 30-second previews of commercial songs.
const AUDIUS = 'https://api.audius.co/v1';
const AUDIUS_APP = 'PulseMediaPlayer';

async function getJSON(url) {
  const res = await fetch(url, { headers: LRCLIB_HEADERS, signal: AbortSignal.timeout(9000) });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  return res.json();
}

async function searchAudius(q) {
  const json = await getJSON(`${AUDIUS}/tracks/search?query=${encodeURIComponent(q)}&limit=20&app_name=${AUDIUS_APP}`);
  return (json.data || [])
    .filter((t) => t && t.id && t.is_streamable !== false)
    .map((t) => ({
      source: 'audius',
      id: String(t.id),
      title: t.title || 'Untitled',
      artist: (t.user && t.user.name) || 'Unknown artist',
      album: '',
      duration: t.duration || 0,
      art: t.artwork ? (t.artwork['480x480'] || t.artwork['150x150'] || '') : '',
      url: `${AUDIUS}/tracks/${encodeURIComponent(t.id)}/stream?app_name=${AUDIUS_APP}`,
      preview: false,
    }));
}

async function searchITunes(q) {
  const json = await getJSON(`https://itunes.apple.com/search?term=${encodeURIComponent(q)}&media=music&entity=song&limit=20`);
  return (json.results || [])
    .filter((t) => t.previewUrl)
    .map((t) => ({
      source: 'itunes',
      id: String(t.trackId),
      title: t.trackName || 'Untitled',
      artist: t.artistName || 'Unknown artist',
      album: t.collectionName || '',
      duration: Math.round((t.trackTimeMillis || 0) / 1000),
      art: (t.artworkUrl100 || '').replace('100x100bb', '600x600bb'),
      url: t.previewUrl,
      preview: true,
    }));
}

ipcMain.handle('online:search', async (_event, query) => {
  const q = String(query || '').trim().slice(0, 200);
  if (!q) return { audius: [], itunes: [], errors: {} };
  const [a, i] = await Promise.allSettled([searchAudius(q), searchITunes(q)]);
  return {
    audius: a.status === 'fulfilled' ? a.value : [],
    itunes: i.status === 'fulfilled' ? i.value : [],
    errors: {
      audius: a.status === 'rejected' ? String(a.reason && a.reason.message || a.reason) : null,
      itunes: i.status === 'rejected' ? String(i.reason && i.reason.message || i.reason) : null,
    },
  };
});

// Proxy for streaming: pulse-remote://stream/?u=<https url>  (only trusted starting hosts)
function isAllowedStreamHost(u) {
  try {
    const url = new URL(u);
    if (url.protocol !== 'https:') return false;
    const h = url.hostname;
    return h === 'api.audius.co' || h === 'audio-ssl.itunes.apple.com' || h.endsWith('.mzstatic.com');
  } catch { return false; }
}

function registerStreamProxy() {
  protocol.handle('pulse-remote', async (request) => {
    const target = new URL(request.url).searchParams.get('u');
    if (!target || !isAllowedStreamHost(target)) return new Response('Forbidden', { status: 403 });
    try {
      const headers = {};
      const range = request.headers.get('range');
      if (range) headers.Range = range;
      const upstream = await net.fetch(target, { headers, bypassCustomProtocolHandlers: true });
      const out = new Headers(upstream.headers);
      out.delete('content-encoding');
      out.set('Access-Control-Allow-Origin', '*');
      return new Response(upstream.body, { status: upstream.status, headers: out });
    } catch {
      return new Response('Bad gateway', { status: 502 });
    }
  });
}

// Lyrics file picker (.lrc / .txt)
ipcMain.handle('dialog:openLyrics', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [
      { name: 'Lyrics', extensions: ['lrc', 'txt'] },
      { name: 'All Files', extensions: ['*'] },
    ],
  });
  if (result.canceled) return null;
  return result.filePaths[0];
});

// Export lyrics as .lrc
ipcMain.handle('dialog:saveLyrics', async (_event, defaultName, text) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: defaultName,
    filters: [{ name: 'Lyrics', extensions: ['lrc'] }],
  });
  if (result.canceled || !result.filePath) return false;
  try { fs.writeFileSync(result.filePath, text, 'utf8'); return true; } catch { return false; }
});

app.whenReady().then(() => {
  registerStreamProxy();
  createWindow();
  buildMenu();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
