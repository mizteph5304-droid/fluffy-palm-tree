@echo off
echo Installing dependencies...
call npm install || goto :err
echo Building Windows exe...
call npm run build:win || goto :err
echo Zipping win-unpacked folder...
if exist dist\win-unpacked (
  powershell -NoProfile -Command "Compress-Archive -Path 'dist\win-unpacked' -DestinationPath 'dist\Pulse-win-unpacked.zip' -Force"
)
echo.
echo Done! Open the "dist" folder. You will find:
echo   Pulse Setup 1.0.0.exe       (installer)
echo   Pulse 1.0.0.exe             (portable)
echo   win-unpacked\               (run Pulse.exe directly)
echo   Pulse-win-unpacked.zip      (the same folder, zipped)
start "" dist
pause
exit /b 0
:err
echo Build failed. See messages above.
pause
exit /b 1
