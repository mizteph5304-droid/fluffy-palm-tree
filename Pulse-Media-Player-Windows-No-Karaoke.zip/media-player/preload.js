const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('pulseAPI', {
  // Dialogs
  openFiles: () => ipcRenderer.invoke('dialog:openFiles'),
  openFolder: () => ipcRenderer.invoke('dialog:openFolder'),
  openSubtitle: () => ipcRenderer.invoke('dialog:openSubtitle'),
  openLyrics: () => ipcRenderer.invoke('dialog:openLyrics'),
  saveLyrics: (name, text) => ipcRenderer.invoke('dialog:saveLyrics', name, text),

  // Metadata / artwork / lyrics
  getMeta: (filePath, wantFull) => ipcRenderer.invoke('meta:get', filePath, wantFull),
  findLyrics: (query) => ipcRenderer.invoke('lyrics:find', query),
  searchOnline: (query) => ipcRenderer.invoke('online:search', query),

  // Filesystem
  scanFolder: (folderPath) => ipcRenderer.invoke('fs:scanFolder', folderPath),
  readText: (filePath) => ipcRenderer.invoke('fs:readText', filePath),
  exists: (filePath) => ipcRenderer.invoke('fs:exists', filePath),
  getFileURL: (filePath) => ipcRenderer.invoke('fs:getFileURL', filePath),

  // Persistence
  loadData: () => ipcRenderer.invoke('data:load'),
  saveData: (data) => ipcRenderer.invoke('data:save', data),

  // Menu events
  onMenu: (channel, callback) => {
    const valid = [
      'menu-add-files',
      'menu-add-folder',
      'menu-clear-library',
      'menu-toggle-play',
      'menu-next',
      'menu-prev',
    ];
    if (valid.includes(channel)) {
      ipcRenderer.on(channel, (_event, ...args) => callback(...args));
    }
  },
});
