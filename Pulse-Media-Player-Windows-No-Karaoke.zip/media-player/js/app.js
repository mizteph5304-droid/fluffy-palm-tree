(() => {
  // ========== State ==========
  const state = {
    library: [],          // { id, name, fullName, type, size, path, added }
    queue: [],            // array of library item ids or objects
    currentIndex: -1,
    isPlaying: false,
    volume: 0.8,
    currentTime: 0,
    duration: 0,
    sort: 'recent',
    search: '',
    playlists: [],        // { id, name, trackIds: [], created }
    currentPlaylistId: null,
    theme: localStorage.getItem('pulse-theme') || 'dark',
    subtitles: [],        // parsed cues { start, end, text }
    currentSubIndex: -1,
    autoLyrics: true,     // look up lyrics online when a song has none
    eq: {
      enabled: true,
      bands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], // 10 bands in dB
    },
  };

  const EQ_FREQS = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
  const EQ_PRESETS = {
    flat:   [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    bass:   [6, 5, 4, 2, 0, 0, 0, 0, 0, 0],
    treble: [0, 0, 0, 0, 0, 1, 3, 5, 6, 6],
    vocal:  [-2, -1, 0, 2, 4, 4, 3, 1, 0, -1],
    rock:   [4, 3, 1, 0, -1, 0, 2, 3, 4, 4],
  };

  // ========== DOM ==========
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  const videoEl = $('#video-player');
  const audioArt = $('#audio-art');
  const stage = $('#stage');
  const subtitleOverlay = $('#subtitle-overlay');
  const playBtn = $('#play-btn');
  const playIcon = $('#play-icon');
  const pauseIcon = $('#pause-icon');
  const progressFill = $('#progress-fill');
  const progressHandle = $('#progress-handle');
  const progressBar = $('#progress-bar');
  const currentTimeEl = $('#current-time');
  const durationEl = $('#duration');
  const trackTitle = $('#track-title');
  const trackSubtitle = $('#track-subtitle');
  const mediaGrid = $('#media-grid');
  const queueList = $('#queue-list');
  const volumeRange = $('#volume-range');
  const libraryStats = $('#library-stats');

  // Web Audio EQ
  let audioCtx = null;
  let sourceNode = null;
  let filters = [];
  let eqConnected = false;

  // ========== Helpers ==========
  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function formatTime(s) {
    if (!isFinite(s) || isNaN(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  }

  function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  }

  function isVideoPath(p) {
    return /\.(mp4|webm|mkv|avi|mov|m4v|ogv|wmv)$/i.test(p);
  }

  function isAudioPath(p) {
    return /\.(mp3|wav|flac|aac|ogg|m4a|opus|wma)$/i.test(p);
  }

  function basename(p) {
    return p.split(/[/\\]/).pop() || p;
  }

  function toast(msg, ms = 2200) {
    const el = $('#toast');
    el.textContent = msg;
    el.classList.remove('hidden');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.classList.add('hidden'), ms);
  }

  // ========== Artwork & tags ==========
  const metaCache = new Map();   // path -> { title, artist, album, lyrics, lyricsSource, art }
  const metaPending = new Map(); // path -> Promise
  const metaQueue = [];
  let metaActive = 0;
  let metaToken = 0;             // guards async now-playing updates against fast track changes
  let currentItem = null;
  const MINI_ART_DEFAULT = $('#mini-art').innerHTML;
  const STAGE_ART_DEFAULT = $('#stage-art').innerHTML;
  const EMPTY_META = { title: null, artist: null, album: null, lyrics: null, lyricsSource: null, art: null };

  function escapeHTML(str) {
    return String(str).replace(/[&<>"']/g, (c) => (
      { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
  }

  function fetchMeta(path) {
    if (metaCache.has(path)) return Promise.resolve(metaCache.get(path));
    if (metaPending.has(path)) return metaPending.get(path);
    const p = new Promise((resolve) => {
      metaQueue.push({ path, resolve });
      pumpMetaQueue();
    });
    metaPending.set(path, p);
    return p;
  }

  function pumpMetaQueue() {
    while (metaActive < 3 && metaQueue.length) {
      const job = metaQueue.shift();
      metaActive++;
      window.pulseAPI.getMeta(job.path, false)
        .catch(() => EMPTY_META)
        .then((m) => {
          const meta = m || EMPTY_META;
          metaCache.set(job.path, meta);
          metaPending.delete(job.path);
          metaActive--;
          job.resolve(meta);
          pumpMetaQueue();
        });
    }
  }

  function applyCardMeta(card, m) {
    const artBox = card.querySelector('.card-art');
    const placeholder = artBox && artBox.querySelector(':scope > svg');
    if (m.art && placeholder) {
      const img = new Image();
      img.src = m.art;
      img.alt = '';
      img.draggable = false;
      artBox.insertBefore(img, artBox.firstChild);
      placeholder.remove();
    }
    const titleEl = card.querySelector('.card-title');
    if (m.title) titleEl.textContent = m.title;
    if (m.artist && !card.querySelector('.card-artist')) {
      const a = document.createElement('div');
      a.className = 'card-artist';
      a.textContent = m.artist;
      titleEl.after(a);
    }
  }

  function hydrateCards() {
    if (!window.pulseAPI) return;
    mediaGrid.querySelectorAll('.media-card[data-id]').forEach((card) => {
      const item = state.library.find((i) => i.id === card.dataset.id);
      if (!item || item.type !== 'audio' || metaCache.has(item.path)) return;
      fetchMeta(item.path).then((m) => {
        const live = mediaGrid.querySelector(`.media-card[data-id="${item.id}"]`);
        if (live) applyCardMeta(live, m);
      });
    });
  }

  function setArt(url) {
    const mini = $('#mini-art');
    const stageArt = $('#stage-art');
    const bg = $('#stage-bg');
    if (url) {
      const make = () => { const img = new Image(); img.src = url; img.alt = ''; img.draggable = false; return img; };
      mini.replaceChildren(make());
      stageArt.replaceChildren(make());
      bg.style.backgroundImage = `url("${url}")`;
      bg.classList.add('on');
    } else {
      mini.innerHTML = MINI_ART_DEFAULT;
      stageArt.innerHTML = STAGE_ART_DEFAULT;
      bg.classList.remove('on');
      bg.style.backgroundImage = '';
    }
  }

  function updateMediaSession(title, artist, album, art) {
    if (!('mediaSession' in navigator) || typeof MediaMetadata === 'undefined') return;
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: title || '',
        artist: artist || '',
        album: album || '',
        artwork: art ? [{ src: art, sizes: '512x512' }] : [],
      });
    } catch { /* ignore */ }
  }

  // Online (streamed) tracks carry their own metadata, so there is no file to read.
  function seedRemoteMeta(item) {
    const rm = item.remoteMeta || {};
    metaCache.set(item.path, { ...EMPTY_META, title: rm.title || null, artist: rm.artist || null, album: rm.album || null, art: rm.art || null });
  }

  function remoteStreamURL(item) {
    return 'pulse-remote://stream/?u=' + encodeURIComponent(item.url);
  }

  // Called whenever a new track starts: reads tags, artwork and lyrics.
  async function onTrackChanged(item) {
    const token = ++metaToken;
    currentItem = item;
    setArt(null);
    updateMediaSession(item.name, '', '', null);
    resetLyrics();
    if (item.lyrics) loadLyricsText(item.lyrics, item.lyricsSource || 'saved', item.lyricsOffset || 0);
    if (item.remote) {
      const rm = item.remoteMeta || {};
      const detail = [rm.artist, rm.album].filter(Boolean).join(' · ');
      trackTitle.textContent = rm.title || item.name;
      trackSubtitle.textContent = (item.preview ? '30s preview · ' : '') + (detail || 'Online');
      $('#stage-title').textContent = rm.title || item.name;
      $('#stage-artist').textContent = (item.preview ? '30-second preview · ' : '') + (detail || 'Online');
      setArt(rm.art || null);
      updateMediaSession(rm.title || item.name, rm.artist, rm.album, rm.art || null);
      if (item.preview) {
        // previews play a slice from the middle of the song, so lyrics could not follow along
        lyr.search = 'preview';
        renderLyrics();
      } else if (!item.lyrics) {
        findLyricsOnline(item, rm, token, false);
      }
      return;
    }
    if (item.type !== 'audio' || !window.pulseAPI) return;

    let m = null;
    try { m = await window.pulseAPI.getMeta(item.path, true); } catch { /* ignore */ }
    if (token !== metaToken || !m) return;
    if (!metaCache.has(item.path)) metaCache.set(item.path, m);

    const title = m.title || item.name;
    const detail = [m.artist, m.album].filter(Boolean).join(' · ');
    trackTitle.textContent = title;
    trackSubtitle.textContent = detail || ('Audio' + (item.size ? ' · ' + formatSize(item.size) : ''));
    $('#stage-title').textContent = title;
    $('#stage-artist').textContent = detail || item.fullName;
    setArt(m.art);
    updateMediaSession(title, m.artist, m.album, m.art);

    if (!item.lyrics && m.lyrics) {
      loadLyricsText(m.lyrics, m.lyricsSource === 'file' ? 'file' : 'tags', item.lyricsOffset || 0);
    }
    const live = mediaGrid.querySelector(`.media-card[data-id="${item.id}"]`);
    if (live) applyCardMeta(live, m);

    if (!item.lyrics && !m.lyrics) findLyricsOnline(item, m, token, false);
  }

  // ========== Persistence ==========
  async function saveData() {
    if (!window.pulseAPI) return;
    const data = {
      library: state.library.map(({ id, name, fullName, type, size, path, added, lyrics, lyricsOffset, lyricsSource, lyricsCheckedAt, remote, url, source, preview, remoteMeta }) => ({
        id, name, fullName, type, size, path, added, lyrics, lyricsOffset, lyricsSource, lyricsCheckedAt, remote, url, source, preview, remoteMeta,
      })),
      playlists: state.playlists,
      volume: state.volume,
      theme: state.theme,
      eq: state.eq,
      autoLyrics: state.autoLyrics,
    };
    await window.pulseAPI.saveData(data);
  }

  async function loadData() {
    if (!window.pulseAPI) return;
    const data = await window.pulseAPI.loadData();
    if (!data) return;

    state.library = data.library || [];
    state.playlists = data.playlists || [];
    if (typeof data.volume === 'number') {
      state.volume = data.volume;
      volumeRange.value = state.volume;
    }
    if (data.theme) {
      state.theme = data.theme;
      applyTheme();
    }
    if (data.eq) {
      state.eq = { ...state.eq, ...data.eq };
    }
    if (typeof data.autoLyrics === 'boolean') state.autoLyrics = data.autoLyrics;

    // Verify files still exist
    const valid = [];
    for (const item of state.library) {
      const exists = item.remote ? true : await window.pulseAPI.exists(item.path);
      if (exists) valid.push(item);
      if (item.remote && item.remoteMeta) seedRemoteMeta(item);
    }
    if (valid.length !== state.library.length) {
      state.library = valid;
      // Clean playlists of missing tracks
      state.playlists.forEach(pl => {
        pl.trackIds = pl.trackIds.filter(id => valid.some(v => v.id === id));
      });
      await saveData();
    }

    renderLibrary();
    renderPlaylists();
    updateStats();
  }

  // ========== Equalizer ==========
  function initEQ() {
    if (audioCtx) return;
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    filters = EQ_FREQS.map((freq, i) => {
      const f = audioCtx.createBiquadFilter();
      f.type = i === 0 ? 'lowshelf' : i === EQ_FREQS.length - 1 ? 'highshelf' : 'peaking';
      f.frequency.value = freq;
      f.Q.value = 1.4;
      f.gain.value = state.eq.bands[i] || 0;
      return f;
    });
    // Chain filters
    for (let i = 0; i < filters.length - 1; i++) {
      filters[i].connect(filters[i + 1]);
    }
  }

  function connectEQ() {
    if (eqConnected || !audioCtx) return;
    try {
      sourceNode = audioCtx.createMediaElementSource(videoEl);
      sourceNode.connect(filters[0]);
      filters[filters.length - 1].connect(audioCtx.destination);
      eqConnected = true;
    } catch (e) {
      console.warn('EQ connect failed (may already be connected):', e);
    }
  }

  function applyEQBands() {
    if (!filters.length) return;
    filters.forEach((f, i) => {
      f.gain.value = state.eq.enabled ? (state.eq.bands[i] || 0) : 0;
    });
  }

  function setEQPreset(name) {
    const preset = EQ_PRESETS[name];
    if (!preset) return;
    state.eq.bands = [...preset];
    applyEQBands();
    renderEQBands();
    $$('.eq-preset').forEach(b => b.classList.toggle('active', b.dataset.preset === name));
    saveData();
  }

  function renderEQBands() {
    const container = $('#eq-bands');
    container.innerHTML = EQ_FREQS.map((freq, i) => {
      const label = freq >= 1000 ? (freq / 1000) + 'k' : freq;
      return `
        <div class="eq-band">
          <input type="range" min="-12" max="12" step="0.5" value="${state.eq.bands[i]}" data-band="${i}" />
          <label>${label}</label>
        </div>`;
    }).join('');

    container.querySelectorAll('input').forEach(input => {
      input.addEventListener('input', () => {
        const idx = parseInt(input.dataset.band, 10);
        state.eq.bands[idx] = parseFloat(input.value);
        applyEQBands();
        $$('.eq-preset').forEach(b => b.classList.remove('active'));
        saveData();
      });
    });
  }

  // ========== Subtitles ==========
  function parseSRT(text) {
    const cues = [];
    const blocks = text.replace(/\r\n/g, '\n').split(/\n\n+/);
    for (const block of blocks) {
      const lines = block.trim().split('\n');
      if (lines.length < 2) continue;
      let timeLine = lines[0];
      let textStart = 1;
      if (/^\d+$/.test(lines[0]) && lines[1]) {
        timeLine = lines[1];
        textStart = 2;
      }
      const m = timeLine.match(/(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)/);
      if (!m) continue;
      const start = (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / 1000;
      const end = (+m[5]) * 3600 + (+m[6]) * 60 + (+m[7]) + (+m[8]) / 1000;
      const text = lines.slice(textStart).join('\n').replace(/<[^>]+>/g, '');
      cues.push({ start, end, text });
    }
    return cues;
  }

  function updateSubtitles() {
    if (!state.subtitles.length) {
      subtitleOverlay.textContent = '';
      return;
    }
    const t = videoEl.currentTime;
    const cue = state.subtitles.find(c => t >= c.start && t <= c.end);
    subtitleOverlay.textContent = cue ? cue.text : '';
  }

  async function loadSubtitleFile() {
    if (!window.pulseAPI) return;
    const path = await window.pulseAPI.openSubtitle();
    if (!path) return;
    const text = await window.pulseAPI.readText(path);
    if (!text) {
      toast('Could not read subtitle file');
      return;
    }
    state.subtitles = parseSRT(text);
    toast(`Loaded ${state.subtitles.length} subtitle cues`);
  }

  // ========== Library ==========
  async function addPaths(filePaths) {
    if (!window.pulseAPI || !filePaths?.length) return;
    const newItems = [];
    for (const p of filePaths) {
      if (!isVideoPath(p) && !isAudioPath(p)) continue;
      // Skip duplicates
      if (state.library.some(i => i.path === p)) continue;

      const name = basename(p);
      const fullName = name;
      const type = isVideoPath(p) ? 'video' : 'audio';
      // size via a quick exists + we already have it from scan, or approximate
      const item = {
        id: uid(),
        name: name.replace(/\.[^/.]+$/, ''),
        fullName,
        type,
        size: 0,
        path: p,
        added: Date.now(),
      };
      state.library.push(item);
      newItems.push(item);
    }
    if (newItems.length) {
      await saveData();
      renderLibrary();
      updateStats();
      toast(`Added ${newItems.length} item${newItems.length > 1 ? 's' : ''}`);
      if (state.currentIndex === -1 && newItems.length) {
        playItem(newItems[0]);
      }
    }
  }

  async function addFolder() {
    if (!window.pulseAPI) return;
    const folder = await window.pulseAPI.openFolder();
    if (!folder) return;
    toast('Scanning folder…');
    const files = await window.pulseAPI.scanFolder(folder);
    if (!files.length) {
      toast('No media files found');
      return;
    }
    const paths = files.map(f => f.path);
    // Enrich with size
    const before = state.library.length;
    for (const f of files) {
      if (state.library.some(i => i.path === f.path)) continue;
      if (!isVideoPath(f.path) && !isAudioPath(f.path)) continue;
      state.library.push({
        id: uid(),
        name: basename(f.path).replace(/\.[^/.]+$/, ''),
        fullName: basename(f.path),
        type: isVideoPath(f.path) ? 'video' : 'audio',
        size: f.size,
        path: f.path,
        added: Date.now(),
      });
    }
    const added = state.library.length - before;
    await saveData();
    renderLibrary();
    updateStats();
    toast(`Added ${added} items from folder`);
  }

  async function addFilesDialog() {
    if (!window.pulseAPI) return;
    const paths = await window.pulseAPI.openFiles();
    await addPaths(paths);
  }

  function removeFromLibrary(id) {
    const idx = state.library.findIndex(i => i.id === id);
    if (idx === -1) return;
    state.library.splice(idx, 1);
    state.queue = state.queue.filter(i => i.id !== id);
    state.playlists.forEach(pl => {
      pl.trackIds = pl.trackIds.filter(tid => tid !== id);
    });
    if (state.currentIndex >= state.queue.length) {
      state.currentIndex = state.queue.length - 1;
    }
    saveData();
    renderLibrary();
    renderQueue();
    renderPlaylists();
    updateStats();
  }

  function filteredLibrary() {
    let list = [...state.library];
    if (state.search) {
      const q = state.search.toLowerCase();
      list = list.filter(i => {
        const m = metaCache.get(i.path);
        return i.name.toLowerCase().includes(q) ||
          i.fullName.toLowerCase().includes(q) ||
          (m && [m.title, m.artist, m.album].some(v => v && v.toLowerCase().includes(q)));
      });
    }
    if (state.sort === 'name') {
      list.sort((a, b) => a.name.localeCompare(b.name));
    } else if (state.sort === 'type') {
      list.sort((a, b) => a.type.localeCompare(b.type) || a.name.localeCompare(b.name));
    } else {
      list.sort((a, b) => b.added - a.added);
    }
    return list;
  }

  function updateStats() {
    const n = state.library.length;
    libraryStats.textContent = `${n} item${n !== 1 ? 's' : ''}`;
  }

  // ========== Playback ==========
  async function playItem(item, addToQueue = true) {
    if (!item || !window.pulseAPI) return;

    if (addToQueue) {
      let idx = state.queue.findIndex(i => i.id === item.id);
      if (idx === -1) {
        state.queue.push(item);
        idx = state.queue.length - 1;
      }
      state.currentIndex = idx;
    }

    const url = item.remote ? remoteStreamURL(item) : await window.pulseAPI.getFileURL(item.path);
    if (!url) {
      toast('File not found: ' + item.fullName);
      removeFromLibrary(item.id);
      return;
    }

    // Init EQ on first play
    initEQ();
    if (audioCtx.state === 'suspended') await audioCtx.resume();

    const media = videoEl;
    // CORS mode is required for the equalizer to process streamed audio
    if (item.remote) media.crossOrigin = 'anonymous'; else media.removeAttribute('crossorigin');
    media.src = url;
    media.load();

    // Clear previous subtitles
    state.subtitles = [];
    subtitleOverlay.textContent = '';

    trackTitle.textContent = item.name;
    trackSubtitle.textContent = (item.type === 'video' ? 'Video' : 'Audio') +
      (item.size ? ' · ' + formatSize(item.size) : '');
    $('#stage-title').textContent = item.name;
    $('#stage-artist').textContent = item.fullName;

    if (item.type === 'video') {
      audioArt.classList.add('hidden');
      videoEl.style.display = 'block';
    } else {
      videoEl.style.display = 'none';
      audioArt.classList.remove('hidden');
    }

    media.volume = state.volume;
    onTrackChanged(item);

    // Connect EQ once
    if (!eqConnected) {
      // Need to wait for canplay
      media.addEventListener('canplay', function onCanPlay() {
        media.removeEventListener('canplay', onCanPlay);
        connectEQ();
        applyEQBands();
      }, { once: true });
    }

    media.play().then(() => {
      state.isPlaying = true;
      updatePlayButton();
    }).catch(err => {
      console.warn('Playback failed:', err);
      toast('Playback failed');
    });

    renderLibrary();
    renderQueue();
  }

  function togglePlay() {
    if (!videoEl.src) {
      if (state.queue.length) playItem(state.queue[0], false);
      return;
    }
    if (videoEl.paused) {
      if (audioCtx?.state === 'suspended') audioCtx.resume();
      videoEl.play();
      state.isPlaying = true;
    } else {
      videoEl.pause();
      state.isPlaying = false;
    }
    updatePlayButton();
  }

  function playNext() {
    if (state.queue.length === 0) return;
    state.currentIndex = (state.currentIndex + 1) % state.queue.length;
    playItem(state.queue[state.currentIndex], false);
  }

  function playPrev() {
    if (state.queue.length === 0) return;
    if (videoEl.currentTime > 3) {
      videoEl.currentTime = 0;
      return;
    }
    state.currentIndex = (state.currentIndex - 1 + state.queue.length) % state.queue.length;
    playItem(state.queue[state.currentIndex], false);
  }

  function updatePlayButton() {
    if (state.isPlaying) {
      playIcon.classList.add('hidden');
      pauseIcon.classList.remove('hidden');
    } else {
      playIcon.classList.remove('hidden');
      pauseIcon.classList.add('hidden');
    }
  }

  function seek(percent) {
    if (!videoEl.duration) return;
    videoEl.currentTime = percent * videoEl.duration;
  }

  // ========== Playlists ==========
  function createPlaylist(name) {
    if (!name.trim()) return;
    const pl = {
      id: uid(),
      name: name.trim(),
      trackIds: [],
      created: Date.now(),
    };
    state.playlists.push(pl);
    saveData();
    renderPlaylists();
    toast('Playlist created');
    return pl;
  }

  function deletePlaylist(id) {
    state.playlists = state.playlists.filter(p => p.id !== id);
    if (state.currentPlaylistId === id) {
      state.currentPlaylistId = null;
      $('#playlist-detail').classList.add('hidden');
      $('#playlists-list').classList.remove('hidden');
    }
    saveData();
    renderPlaylists();
  }

  function addToPlaylist(trackId, playlistId) {
    const pl = state.playlists.find(p => p.id === playlistId);
    if (!pl) return;
    if (!pl.trackIds.includes(trackId)) {
      pl.trackIds.push(trackId);
      saveData();
      toast('Added to playlist');
      if (state.currentPlaylistId === playlistId) renderPlaylistDetail();
    }
  }

  function playPlaylist(id) {
    const pl = state.playlists.find(p => p.id === id);
    if (!pl || !pl.trackIds.length) {
      toast('Playlist is empty');
      return;
    }
    const tracks = pl.trackIds
      .map(tid => state.library.find(i => i.id === tid))
      .filter(Boolean);
    if (!tracks.length) return;
    state.queue = [...tracks];
    state.currentIndex = 0;
    playItem(tracks[0], false);
    renderQueue();
  }

  // ========== Render ==========
  function renderLibrary() {
    const list = filteredLibrary();
    if (list.length === 0) {
      mediaGrid.innerHTML = `
        <div class="empty-state">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2">
            <path d="M9 18V5l12-2v13"/>
            <circle cx="6" cy="18" r="3"/>
            <circle cx="18" cy="16" r="3"/>
          </svg>
          <h2>No media yet</h2>
          <p>Use File → Add Files / Add Folder, or the sidebar buttons</p>
        </div>`;
      return;
    }

    const currentId = state.queue[state.currentIndex]?.id;
    mediaGrid.innerHTML = list.map(item => {
      const m = metaCache.get(item.path);
      const cardTitle = escapeHTML((m && m.title) || item.name);
      return `
      <div class="media-card ${item.id === currentId ? 'playing' : ''}" data-id="${item.id}">
        <div class="card-art">
          ${m && m.art ? `<img src="${m.art}" alt="" draggable="false">` : `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2">
            ${item.type === 'video'
              ? `<rect x="2" y="4" width="20" height="16" rx="2"/><polygon points="10 9 16 12 10 15"/>`
              : `<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>`}
          </svg>`}
          <div class="play-overlay">
            <button data-play="${item.id}">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
            </button>
          </div>
        </div>
        <div class="card-title" title="${escapeHTML(item.fullName)}">${cardTitle}</div>
        ${m && m.artist ? `<div class="card-artist">${escapeHTML(m.artist)}</div>` : ''}
        <div class="card-meta">
          <span class="badge ${item.type}">${item.type}</span>
          ${item.remote ? `<span class="badge online">${item.preview ? 'preview' : 'online'}</span>` : ''}
          ${item.size ? `<span>${formatSize(item.size)}</span>` : ''}
        </div>
      </div>
    `;
    }).join('');
    hydrateCards();

    mediaGrid.querySelectorAll('.media-card').forEach(card => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('[data-play]')) return;
        const item = state.library.find(i => i.id === card.dataset.id);
        if (item) playItem(item);
      });
      card.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        showContextMenu(e, card.dataset.id);
      });
    });
    mediaGrid.querySelectorAll('[data-play]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const item = state.library.find(i => i.id === btn.dataset.play);
        if (item) playItem(item);
      });
    });
  }

  function renderQueue() {
    if (state.queue.length === 0) {
      queueList.innerHTML = `<div class="empty-state"><p>Queue is empty</p></div>`;
      return;
    }
    queueList.innerHTML = state.queue.map((item, i) => `
      <div class="queue-item ${i === state.currentIndex ? 'playing' : ''}" data-idx="${i}">
        <span class="idx">${i === state.currentIndex && state.isPlaying ? '▶' : i + 1}</span>
        <div class="info">
          <div class="title">${item.name}</div>
          <div class="meta">${item.type}${item.size ? ' · ' + formatSize(item.size) : ''}</div>
        </div>
      </div>
    `).join('');

    queueList.querySelectorAll('.queue-item').forEach(el => {
      el.addEventListener('click', () => {
        const idx = parseInt(el.dataset.idx, 10);
        state.currentIndex = idx;
        playItem(state.queue[idx], false);
      });
    });
  }

  function renderPlaylists() {
    const list = $('#playlists-list');
    if (state.playlists.length === 0) {
      list.innerHTML = `<div class="empty-state"><p>Create a playlist to organize your media</p></div>`;
      return;
    }
    list.innerHTML = state.playlists.map(pl => `
      <div class="playlist-item" data-id="${pl.id}">
        <div class="info">
          <div class="title">${pl.name}</div>
          <div class="meta">${pl.trackIds.length} track${pl.trackIds.length !== 1 ? 's' : ''}</div>
        </div>
        <span class="count">${pl.trackIds.length}</span>
      </div>
    `).join('');

    list.querySelectorAll('.playlist-item').forEach(el => {
      el.addEventListener('click', () => openPlaylistDetail(el.dataset.id));
    });
  }

  function openPlaylistDetail(id) {
    state.currentPlaylistId = id;
    $('#playlists-list').classList.add('hidden');
    $('#playlist-detail').classList.remove('hidden');
    renderPlaylistDetail();
  }

  function renderPlaylistDetail() {
    const pl = state.playlists.find(p => p.id === state.currentPlaylistId);
    if (!pl) return;
    $('#playlist-detail-title').textContent = pl.name;
    const tracks = pl.trackIds
      .map(tid => state.library.find(i => i.id === tid))
      .filter(Boolean);

    const container = $('#playlist-tracks');
    if (!tracks.length) {
      container.innerHTML = `<div class="empty-state"><p>No tracks in this playlist</p></div>`;
      return;
    }
    container.innerHTML = tracks.map((item, i) => `
      <div class="queue-item" data-id="${item.id}">
        <span class="idx">${i + 1}</span>
        <div class="info">
          <div class="title">${item.name}</div>
          <div class="meta">${item.type}</div>
        </div>
      </div>
    `).join('');

    container.querySelectorAll('.queue-item').forEach(el => {
      el.addEventListener('click', () => {
        const item = state.library.find(i => i.id === el.dataset.id);
        if (item) playItem(item);
      });
    });
  }

  // ========== Context Menu ==========
  const contextMenu = $('#context-menu');
  let contextTargetId = null;

  function showContextMenu(e, id) {
    contextTargetId = id;
    contextMenu.style.left = Math.min(e.clientX, window.innerWidth - 200) + 'px';
    contextMenu.style.top = Math.min(e.clientY, window.innerHeight - 160) + 'px';
    contextMenu.classList.remove('hidden');
  }

  function hideContextMenu() {
    contextMenu.classList.add('hidden');
    contextTargetId = null;
  }

  contextMenu.addEventListener('click', (e) => {
    const action = e.target.dataset.action;
    if (!action || !contextTargetId) return;
    const item = state.library.find(i => i.id === contextTargetId);
    if (!item) return;

    if (action === 'play') playItem(item);
    if (action === 'add-queue') {
      if (!state.queue.find(i => i.id === item.id)) {
        state.queue.push(item);
        renderQueue();
        toast('Added to queue');
      }
    }
    if (action === 'add-playlist') {
      openAddToPlaylistModal(item.id);
    }
    if (action === 'remove') {
      removeFromLibrary(item.id);
      toast('Removed');
    }
    hideContextMenu();
  });

  document.addEventListener('click', hideContextMenu);

  // ========== Modal ==========
  let modalMode = null; // 'create' | 'add-to'
  let modalTrackId = null;

  function openCreatePlaylistModal() {
    modalMode = 'create';
    modalTrackId = null;
    $('#modal-title').textContent = 'New Playlist';
    $('#modal-input').value = '';
    $('#modal-input').classList.remove('hidden');
    $('#modal-list').classList.add('hidden');
    $('#modal-confirm').textContent = 'Create';
    $('#modal-overlay').classList.remove('hidden');
    $('#modal-input').focus();
  }

  function openAddToPlaylistModal(trackId) {
    modalMode = 'add-to';
    modalTrackId = trackId;
    $('#modal-title').textContent = 'Add to Playlist';
    $('#modal-input').classList.add('hidden');
    const list = $('#modal-list');
    list.classList.remove('hidden');
    if (state.playlists.length === 0) {
      list.innerHTML = '<p style="color:var(--text-muted);padding:8px;">No playlists yet. Create one first.</p>';
    } else {
      list.innerHTML = state.playlists.map(pl =>
        `<button data-pl="${pl.id}">${pl.name}</button>`
      ).join('');
      list.querySelectorAll('button').forEach(btn => {
        btn.addEventListener('click', () => {
          addToPlaylist(modalTrackId, btn.dataset.pl);
          closeModal();
        });
      });
    }
    $('#modal-confirm').textContent = 'New…';
    $('#modal-overlay').classList.remove('hidden');
  }

  function closeModal() {
    $('#modal-overlay').classList.add('hidden');
    modalMode = null;
    modalTrackId = null;
  }

  $('#modal-cancel').addEventListener('click', closeModal);
  $('#modal-confirm').addEventListener('click', () => {
    if (modalMode === 'create') {
      const name = $('#modal-input').value;
      createPlaylist(name);
      closeModal();
    } else if (modalMode === 'add-to') {
      // Create new then add
      openCreatePlaylistModal();
    }
  });
  $('#modal-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') $('#modal-confirm').click();
  });

  // ========== Views ==========
  function switchView(name) {
    $$('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.view === name));
    $$('.view').forEach(v => v.classList.toggle('active', v.id === name + '-view'));
    // Reset playlist detail when leaving
    if (name !== 'playlists') {
      state.currentPlaylistId = null;
      $('#playlist-detail').classList.add('hidden');
      $('#playlists-list').classList.remove('hidden');
    }
  }

  // ========== Theme ==========
  function applyTheme() {
    document.documentElement.setAttribute('data-theme', state.theme === 'light' ? 'light' : '');
    localStorage.setItem('pulse-theme', state.theme);
  }

  // ========== Lyrics ==========
  const linesEl = $('#lyrics-lines');
  const scrollEl = $('#lyrics-scroll');
  const emptyEl = $('#lyrics-empty');
  const lyricsPanel = $('#lyrics-panel');
  const offsetEl = $('#lyrics-offset');
  const lyricsModal = $('#lyrics-modal');
  const lyricsText = $('#lyrics-text');
  const SYNC_REACTION = 0.25; // seconds: compensates for the delay between hearing a line and pressing Enter

  const lyr = { lines: [], synced: false, active: -1, raw: '', source: null, offset: 0, pauseUntil: 0, needsRecenter: false, search: 'idle' };
  const sync = { on: false, texts: [], stamps: [], idx: 0 };

  // Parses LRC (multi-timestamp, [offset:], enhanced <mm:ss> tags) or plain text.
  function parseLyrics(text) {
    const rows = text.replace(/\r\n?/g, '\n').split('\n');
    const timed = [];
    const plain = [];
    let offset = 0;
    let hasTime = false;
    const lineRe = /^\s*((?:\[\d{1,3}:\d{2}(?:[.:]\d{1,3})?\])+)(.*)$/;
    const stampRe = /\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g;

    for (const row of rows) {
      const off = row.match(/^\s*\[offset:\s*([+-]?\d+)\s*\]/i);
      if (off) { offset = parseInt(off[1], 10) / 1000; continue; }
      if (/^\s*\[(ar|ti|al|au|by|length|re|ve|la|id|#):/i.test(row)) continue;
      const m = row.match(lineRe);
      if (m) {
        hasTime = true;
        const txt = m[2].replace(/<\d{1,3}:\d{2}(?:[.:]\d{1,3})?>/g, '').trim();
        for (const st of m[1].matchAll(stampRe)) {
          const t = parseInt(st[1], 10) * 60 + parseInt(st[2], 10) + (st[3] ? parseFloat('0.' + st[3]) : 0);
          timed.push({ t, text: txt });
        }
      } else {
        plain.push({ t: null, text: row.trim() });
      }
    }

    if (hasTime) {
      timed.sort((a, b) => a.t - b.t);
      timed.forEach(l => { l.t = Math.max(0, l.t - offset); });
      return { synced: true, lines: timed };
    }
    // plain: trim blank edges and collapse repeated blank lines
    const out = [];
    for (const l of plain) {
      if (!l.text && (!out.length || !out[out.length - 1].text)) continue;
      out.push(l);
    }
    while (out.length && !out[out.length - 1].text) out.pop();
    return { synced: false, lines: out };
  }

  function lrcStamp(sec) {
    const m = Math.floor(sec / 60);
    const s = sec - m * 60;
    return `${String(m).padStart(2, '0')}:${s.toFixed(2).padStart(5, '0')}`;
  }

  function loadLyricsText(text, source, offset) {
    text = (text || '').replace(/^\uFEFF/, '');
    const parsed = parseLyrics(text);
    lyr.raw = text;
    lyr.source = parsed.lines.length ? source : null;
    lyr.offset = offset || 0;
    lyr.synced = parsed.synced;
    lyr.lines = parsed.lines;
    lyr.active = -1;
    renderLyrics();
  }

  function resetLyrics() {
    cancelSync(true);
    lyr.lines = [];
    lyr.raw = '';
    lyr.source = null;
    lyr.synced = false;
    lyr.active = -1;
    lyr.offset = 0;
    lyr.search = 'idle';
    renderLyrics();
  }

  const EMPTY_TEXT = {
    idle:         ['No lyrics for this song yet', 'Search online, paste them in, or load an .lrc file to have them follow the music.', true],
    searching:    ['Searching for lyrics…', 'Looking on LRCLIB.', false],
    notfound:     ['No lyrics found online', 'LRCLIB has no match for this song. You can paste your own or load an .lrc file.', true],
    offline:      ['Could not reach the lyrics service', 'Check your internet connection and try again.', true],
    instrumental: ['This track is instrumental', 'LRCLIB lists it as having no lyrics.', true],
    preview:      ['Lyrics are off for previews', 'A 30-second preview plays a section from the middle of the song, so lyrics cannot follow along.', false],
  };

  function renderEmptyState() {
    const [title, text, showActions] = EMPTY_TEXT[lyr.search] || EMPTY_TEXT.idle;
    $('#lyrics-empty-title').textContent = title;
    $('#lyrics-empty-text').textContent = text;
    $('#lyrics-empty-actions').classList.toggle('hidden', !showActions);
  }

  function waitForDuration() {
    return new Promise((resolve) => {
      if (isFinite(videoEl.duration) && videoEl.duration > 0) return resolve(videoEl.duration);
      const done = () => { videoEl.removeEventListener('loadedmetadata', done); resolve(isFinite(videoEl.duration) ? videoEl.duration : 0); };
      videoEl.addEventListener('loadedmetadata', done);
      setTimeout(done, 2000);
    });
  }

  // Looks the song up on LRCLIB and saves what it finds with the song, so it is only searched once.
  async function findLyricsOnline(item, meta, token, force) {
    if (!window.pulseAPI || sync.on) return;
    if (!force) {
      if (!state.autoLyrics) return;
      const WEEK = 7 * 24 * 3600 * 1000;
      if (item.lyricsCheckedAt && Date.now() - item.lyricsCheckedAt < WEEK) { lyr.search = 'notfound'; renderLyrics(); return; }
    }
    lyr.search = 'searching';
    renderLyrics();
    const duration = await waitForDuration();
    if (token !== metaToken) return;

    let res;
    try {
      res = await window.pulseAPI.findLyrics({
        title: meta && meta.title, artist: meta && meta.artist, album: meta && meta.album,
        duration, fileName: item.fullName,
      });
    } catch { res = { status: 'offline' }; }
    if (token !== metaToken) return;

    if (res.status === 'found' && res.lyrics) {
      item.lyrics = res.lyrics;
      item.lyricsSource = 'online';
      delete item.lyricsCheckedAt;
      saveData();
      loadLyricsText(res.lyrics, 'online', item.lyricsOffset || 0);
      toast(res.synced ? 'Found synced lyrics' : 'Found lyrics (not synced)');
      return;
    }
    if (res.status === 'notfound' || res.status === 'instrumental') {
      item.lyricsCheckedAt = Date.now();
      saveData();
    }
    lyr.search = res.status in EMPTY_TEXT ? res.status : 'notfound';
    renderLyrics();
  }

  function formatOffset() {
    return (lyr.offset > 0 ? '+' : '') + lyr.offset.toFixed(1) + 's';
  }

  function renderLyrics() {
    if (sync.on) return;
    const has = lyr.lines.length > 0;
    emptyEl.classList.toggle('hidden', has);
    if (!has) renderEmptyState();
    linesEl.className = 'lyrics-lines' + (has ? (lyr.synced ? ' synced' : ' plain') : '');
    linesEl.innerHTML = lyr.lines.map((l, i) => {
      if (l.text) return `<div class="lyric-line" data-i="${i}">${escapeHTML(l.text)}</div>`;
      return lyr.synced ? `<div class="lyric-line gap" data-i="${i}">♪</div>` : '<div class="lyric-spacer"></div>';
    }).join('');

    $('#lyrics-timing').classList.toggle('hidden', !(has && lyr.synced));
    $('#lyrics-sync-btn').classList.toggle('hidden', !(has && !lyr.synced));
    offsetEl.textContent = formatOffset();

    const where = { saved: 'saved with this song', file: 'from .lrc file', tags: 'from file tags', online: 'found online (LRCLIB)' }[lyr.source];
    $('#lyrics-status').textContent = has
      ? (lyr.synced ? 'Synced lyrics' : 'Lyrics, not synced') + (where ? ' · ' + where : '')
      : '';

    scrollEl.scrollTop = 0;
    if (lyr.synced) setActive(findActive(videoEl.currentTime - lyr.offset), true);
  }

  // Index of the last line whose time is <= t (binary search), or -1.
  function findActive(t) {
    const lines = lyr.lines;
    let lo = 0, hi = lines.length - 1, ans = -1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (lines[mid].t <= t) { ans = mid; lo = mid + 1; } else { hi = mid - 1; }
    }
    return ans;
  }

  function scrollToLine(el, instant) {
    if (!el) return;
    scrollEl.scrollTo({
      top: el.offsetTop - scrollEl.clientHeight / 2 + el.offsetHeight / 2,
      behavior: instant ? 'auto' : 'smooth',
    });
  }

  function setActive(idx, force) {
    if (idx === lyr.active && !force) return;
    const els = linesEl.children;
    if (els[lyr.active]) els[lyr.active].classList.remove('active');
    lyr.active = idx;
    const el = els[idx];
    if (!el) return;
    el.classList.add('active');
    if (Date.now() < lyr.pauseUntil) { lyr.needsRecenter = true; return; }
    scrollToLine(el, !!force);
  }

  // Follow the song in real time (requestAnimationFrame is much smoother than 'timeupdate')
  function lyricsTick() {
    requestAnimationFrame(lyricsTick);
    if (!lyr.synced || sync.on || stage.classList.contains('hidden') || audioArt.classList.contains('hidden')) return;
    const idx = findActive(videoEl.currentTime - lyr.offset);
    if (idx !== lyr.active) setActive(idx, false);
    else if (lyr.needsRecenter && Date.now() >= lyr.pauseUntil) {
      lyr.needsRecenter = false;
      scrollToLine(linesEl.children[lyr.active], false);
    }
  }

  function pauseFollow() { lyr.pauseUntil = Date.now() + 3500; }
  scrollEl.addEventListener('wheel', pauseFollow, { passive: true });
  scrollEl.addEventListener('touchmove', pauseFollow, { passive: true });
  scrollEl.addEventListener('pointerdown', pauseFollow);

  linesEl.addEventListener('click', (e) => {
    if (!lyr.synced || sync.on) return;
    const el = e.target.closest('.lyric-line');
    if (!el) return;
    const line = lyr.lines[parseInt(el.dataset.i, 10)];
    if (!line) return;
    lyr.pauseUntil = 0;
    videoEl.currentTime = line.t + lyr.offset + 0.02;
    setActive(parseInt(el.dataset.i, 10), true);
  });

  function nudgeOffset(delta) {
    lyr.offset = Math.round((lyr.offset + delta) * 10) / 10;
    offsetEl.textContent = formatOffset();
    if (currentItem) {
      if (lyr.offset) currentItem.lyricsOffset = lyr.offset; else delete currentItem.lyricsOffset;
      saveData();
    }
    lyr.pauseUntil = 0;
    setActive(findActive(videoEl.currentTime - lyr.offset), true);
  }
  $('#lyrics-earlier').addEventListener('click', () => nudgeOffset(-0.5));
  $('#lyrics-later').addEventListener('click', () => nudgeOffset(0.5));

  // ----- stage helpers -----
  function openStage() {
    stage.classList.remove('hidden');
    if (lyr.synced) requestAnimationFrame(() => setActive(findActive(videoEl.currentTime - lyr.offset), true));
  }

  function toggleLyricsStage() {
    if (!stage.classList.contains('hidden')) { stage.classList.add('hidden'); return; }
    if (!currentItem) { toast('Play a song first'); return; }
    if (currentItem.type !== 'audio') { toast('Lyrics are for audio files'); return; }
    openStage();
  }

  // ----- editor -----
  function requireAudioItem() {
    if (!currentItem || currentItem.type !== 'audio') { toast('Play a song first'); return false; }
    return true;
  }

  function openLyricsEditor() {
    if (!requireAudioItem()) return;
    lyricsText.value = lyr.raw || '';
    $('#lyrics-auto-toggle').checked = state.autoLyrics;
    lyricsModal.classList.remove('hidden');
    lyricsText.focus();
  }

  function closeLyricsEditor() { lyricsModal.classList.add('hidden'); }

  function applyUserLyrics(text) {
    if (!currentItem) return;
    text = (text || '').trim();
    if (text) {
      currentItem.lyrics = text;
      delete currentItem.lyricsSource;
      loadLyricsText(text, 'saved', currentItem.lyricsOffset || 0);
    } else {
      delete currentItem.lyrics;
      delete currentItem.lyricsSource;
      const m = metaCache.get(currentItem.path);
      resetLyrics();
      if (m && m.lyrics) loadLyricsText(m.lyrics, m.lyricsSource === 'file' ? 'file' : 'tags', currentItem.lyricsOffset || 0);
    }
    saveData();
  }

  async function pickLyricsFile() {
    if (!window.pulseAPI) return null;
    const p = await window.pulseAPI.openLyrics();
    if (!p) return null;
    const text = await window.pulseAPI.readText(p);
    if (!text || !text.trim()) { toast('Could not read that lyrics file'); return null; }
    return text.replace(/^\uFEFF/, '');
  }

  $('#lyrics-search-btn').addEventListener('click', () => {
    if (!requireAudioItem()) return;
    findLyricsOnline(currentItem, metaCache.get(currentItem.path), metaToken, true);
  });
  $('#lyrics-edit-btn').addEventListener('click', openLyricsEditor);
  $('#lyrics-auto-toggle').addEventListener('change', (e) => {
    state.autoLyrics = e.target.checked;
    saveData();
  });
  $('#lyrics-add-btn').addEventListener('click', openLyricsEditor);
  $('#lyrics-load-btn').addEventListener('click', async () => {
    if (!requireAudioItem()) return;
    const text = await pickLyricsFile();
    if (text) { applyUserLyrics(text); toast(lyr.synced ? 'Synced lyrics added' : 'Lyrics added'); }
  });
  $('#lyrics-modal-cancel').addEventListener('click', closeLyricsEditor);
  $('#lyrics-modal-save').addEventListener('click', () => {
    const had = !!lyricsText.value.trim();
    applyUserLyrics(lyricsText.value);
    closeLyricsEditor();
    toast(had ? (lyr.synced ? 'Lyrics saved. They will follow the song' : 'Lyrics saved. Use Sync lines to make them follow the song') : 'Lyrics removed');
  });
  $('#lyrics-modal-load').addEventListener('click', async () => {
    const text = await pickLyricsFile();
    if (text) lyricsText.value = text;
  });
  $('#lyrics-modal-export').addEventListener('click', async () => {
    if (!lyricsText.value.trim() || !window.pulseAPI) return;
    const ok = await window.pulseAPI.saveLyrics((currentItem ? currentItem.name : 'lyrics') + '.lrc', lyricsText.value);
    if (ok) toast('Lyrics exported');
  });
  $('#lyrics-modal-sync').addEventListener('click', () => startSync(lyricsText.value));
  $('#lyrics-sync-btn').addEventListener('click', () => startSync(lyr.raw));
  lyricsText.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeLyricsEditor(); });

  // ----- tap-to-sync -----
  function startSync(text) {
    if (!requireAudioItem()) return;
    const texts = parseLyrics(text || '').lines.map(l => l.text).filter(Boolean);
    if (!texts.length) { toast('Add some lyrics first'); return; }
    closeLyricsEditor();
    sync.on = true;
    sync.texts = texts;
    sync.stamps = [];
    sync.idx = 0;
    emptyEl.classList.add('hidden');
    lyricsPanel.classList.add('syncing');
    $('#sync-bar').classList.remove('hidden');
    openStage();
    renderSync();
    videoEl.currentTime = 0;
    videoEl.play().catch(() => {});
  }

  function renderSync() {
    const done = sync.idx >= sync.texts.length;
    linesEl.className = 'lyrics-lines syncing';
    linesEl.innerHTML = sync.texts.map((t, i) => {
      const cls = 'lyric-line' + (i < sync.idx ? ' stamped' : '') + (i === sync.idx ? ' active' : '');
      const stamp = i < sync.idx ? `<span class="lyric-stamp">${lrcStamp(sync.stamps[i])}</span>` : '';
      return `<div class="${cls}">${stamp}${escapeHTML(t)}</div>`;
    }).join('');
    $('#sync-progress').textContent = done
      ? 'All lines timed. Press Save'
      : `Line ${sync.idx + 1} of ${sync.texts.length}`;
    $('#sync-tap').disabled = done;
    scrollToLine(linesEl.children[Math.min(sync.idx, sync.texts.length - 1)], false);
  }

  function syncTap() {
    if (!sync.on || sync.idx >= sync.texts.length) return;
    sync.stamps[sync.idx] = Math.max(0, videoEl.currentTime - SYNC_REACTION);
    sync.idx++;
    renderSync();
  }

  function syncUndo() {
    if (!sync.on || sync.idx === 0) return;
    const removed = sync.stamps[sync.idx - 1];
    sync.idx--;
    sync.stamps.length = sync.idx;
    videoEl.currentTime = Math.max(0, removed - 2);
    renderSync();
  }

  function syncSave() {
    if (!sync.on) return;
    if (!sync.idx) { toast('Press Enter as the first line begins'); return; }
    const total = sync.texts.length;
    const count = sync.idx;
    const lrc = sync.texts.slice(0, count).map((t, i) => `[${lrcStamp(sync.stamps[i])}]${t}`).join('\n');
    cancelSync(true);
    applyUserLyrics(lrc);
    toast(count === total ? `Synced ${count} lines` : `Saved ${count} of ${total} lines`);
  }

  function cancelSync(silent) {
    if (!sync.on) return;
    sync.on = false;
    lyricsPanel.classList.remove('syncing');
    $('#sync-bar').classList.add('hidden');
    if (!silent) renderLyrics();
  }

  $('#sync-tap').addEventListener('click', syncTap);
  $('#sync-undo').addEventListener('click', syncUndo);
  $('#sync-save').addEventListener('click', syncSave);
  $('#sync-cancel').addEventListener('click', () => cancelSync(false));
  $('#lyrics-btn').addEventListener('click', toggleLyricsStage);

  // ========== Discover (search online) ==========
  const discoverInput = $('#discover-input');
  const discoverResults = $('#discover-results');
  const discover = { results: [], token: 0 };

  function remotePath(r) { return `${r.source}:${r.id}`; }

  function findRemoteItem(r) {
    const path = remotePath(r);
    return state.library.find(i => i.path === path) || state.queue.find(i => i.path === path) || null;
  }

  function makeRemoteItem(r) {
    return findRemoteItem(r) || {
      id: uid(),
      name: r.title,
      fullName: `${r.artist} - ${r.title}`,
      type: 'audio',
      size: 0,
      path: remotePath(r),
      added: Date.now(),
      remote: true,
      source: r.source,
      url: r.url,
      preview: r.preview,
      remoteMeta: { title: r.title, artist: r.artist, album: r.album, art: r.art, duration: r.duration },
    };
  }

  function addRemoteToLibrary(r) {
    const item = makeRemoteItem(r);
    if (state.library.some(i => i.path === item.path)) { toast('Already in your library'); return; }
    item.added = Date.now();
    state.library.push(item);
    seedRemoteMeta(item);
    saveData();
    renderLibrary();
    updateStats();
    renderDiscover();
    toast('Added to library');
  }

  function renderDiscoverGroup(title, note, list, offset) {
    if (!list.length) return '';
    const playingPath = currentItem && currentItem.path;
    const rows = list.map((r, k) => {
      const i = offset + k;
      const inLib = state.library.some(x => x.path === remotePath(r));
      return `
        <div class="result-row ${playingPath === remotePath(r) ? 'playing' : ''}" data-i="${i}">
          ${r.art ? `<img class="result-art" src="${escapeHTML(r.art)}" alt="" draggable="false">` : '<div class="result-art"></div>'}
          <div class="result-info">
            <div class="result-title">${escapeHTML(r.title)}</div>
            <div class="result-sub">${escapeHTML([r.artist, r.album].filter(Boolean).join(' · '))}</div>
          </div>
          <span class="result-time">${r.duration ? formatTime(r.duration) : ''}</span>
          <button class="result-add ${inLib ? 'added' : ''}" data-add="${i}" title="${inLib ? 'In your library' : 'Add to library'}">${inLib ? '✓' : '+'}</button>
        </div>`;
    }).join('');
    return `<div class="result-group"><h3>${title}</h3><div class="group-note">${note}</div>${rows}</div>`;
  }

  function renderDiscover(message) {
    if (message) { discoverResults.innerHTML = `<div class="empty-state"><p>${escapeHTML(message)}</p></div>`; return; }
    const full = discover.results.filter(r => !r.preview);
    const prev = discover.results.filter(r => r.preview);
    discoverResults.innerHTML =
      renderDiscoverGroup('Full tracks', 'From independent artists on Audius', full, 0) +
      renderDiscoverGroup('30-second previews', 'From Apple. Commercial songs play a short preview', prev, full.length);
    // indices above refer to the order full + prev
    discover.results = [...full, ...prev];
  }

  async function runDiscoverSearch() {
    const q = discoverInput.value.trim();
    if (!q) return;
    if (!window.pulseAPI) return;
    const token = ++discover.token;
    renderDiscover('Searching…');
    let res;
    try { res = await window.pulseAPI.searchOnline(q); } catch { res = null; }
    if (token !== discover.token) return;
    if (!res) { renderDiscover('Could not reach the search services. Check your internet connection.'); return; }
    discover.results = [...res.audius, ...res.itunes];
    if (!discover.results.length) {
      const bothFailed = res.errors.audius && res.errors.itunes;
      renderDiscover(bothFailed ? 'Could not reach the search services. Check your internet connection.' : `No results for "${q}"`);
      return;
    }
    renderDiscover();
    const failed = [res.errors.audius && 'Audius', res.errors.itunes && 'Apple previews'].filter(Boolean);
    if (failed.length) toast(`${failed.join(' and ')} could not be reached`, 3200);
  }

  $('#discover-btn').addEventListener('click', runDiscoverSearch);
  discoverInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') runDiscoverSearch(); });
  discoverResults.addEventListener('click', (e) => {
    const addBtn = e.target.closest('[data-add]');
    if (addBtn) {
      e.stopPropagation();
      const r = discover.results[parseInt(addBtn.dataset.add, 10)];
      if (r) addRemoteToLibrary(r);
      return;
    }
    const row = e.target.closest('.result-row');
    if (!row) return;
    const r = discover.results[parseInt(row.dataset.i, 10)];
    if (!r) return;
    playItem(makeRemoteItem(r)).then(() => { if (!discoverResults.querySelector('.empty-state')) renderDiscover(); });
  });

  // ========== Events ==========
  $$('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => switchView(btn.dataset.view));
  });

  $('#sidebar-add-files').addEventListener('click', addFilesDialog);
  $('#sidebar-add-folder').addEventListener('click', addFolder);

  $('#search-input').addEventListener('input', (e) => {
    state.search = e.target.value.trim();
    renderLibrary();
  });

  $$('.sort-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      $$('.sort-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.sort = btn.dataset.sort;
      renderLibrary();
    });
  });

  playBtn.addEventListener('click', togglePlay);
  $('#next-btn').addEventListener('click', playNext);
  $('#prev-btn').addEventListener('click', playPrev);

  // Progress seeking
  let isSeeking = false;
  progressBar.addEventListener('mousedown', (e) => {
    isSeeking = true;
    const rect = progressBar.getBoundingClientRect();
    const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    seek(pct);
    progressFill.style.width = (pct * 100) + '%';
    progressHandle.style.left = (pct * 100) + '%';
  });
  document.addEventListener('mousemove', (e) => {
    if (!isSeeking) return;
    const rect = progressBar.getBoundingClientRect();
    const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    seek(pct);
    progressFill.style.width = (pct * 100) + '%';
    progressHandle.style.left = (pct * 100) + '%';
  });
  document.addEventListener('mouseup', () => { isSeeking = false; });

  volumeRange.addEventListener('input', () => {
    state.volume = parseFloat(volumeRange.value);
    videoEl.volume = state.volume;
    saveData();
  });

  $('#expand-btn').addEventListener('click', () => {
    if (!videoEl.src) return;
    openStage();
  });
  $('#close-stage').addEventListener('click', () => stage.classList.add('hidden'));
  $('#load-subtitle-btn').addEventListener('click', loadSubtitleFile);

  $('#clear-queue-btn').addEventListener('click', () => {
    state.queue = [];
    state.currentIndex = -1;
    renderQueue();
  });

  $('#create-playlist-btn').addEventListener('click', openCreatePlaylistModal);
  $('#back-to-playlists').addEventListener('click', () => {
    state.currentPlaylistId = null;
    $('#playlist-detail').classList.add('hidden');
    $('#playlists-list').classList.remove('hidden');
  });
  $('#play-playlist-btn').addEventListener('click', () => {
    if (state.currentPlaylistId) playPlaylist(state.currentPlaylistId);
  });
  $('#delete-playlist-btn').addEventListener('click', () => {
    if (state.currentPlaylistId && confirm('Delete this playlist?')) {
      deletePlaylist(state.currentPlaylistId);
    }
  });

  // EQ panel
  $('#eq-toggle').addEventListener('click', () => {
    $('#eq-panel').classList.toggle('hidden');
  });
  $('#eq-close').addEventListener('click', () => $('#eq-panel').classList.add('hidden'));
  $('#eq-enabled').addEventListener('change', (e) => {
    state.eq.enabled = e.target.checked;
    applyEQBands();
    saveData();
  });
  $$('.eq-preset').forEach(btn => {
    btn.addEventListener('click', () => setEQPreset(btn.dataset.preset));
  });

  $('#theme-toggle').addEventListener('click', () => {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    applyTheme();
    saveData();
  });

  // Media events
  videoEl.addEventListener('timeupdate', () => {
    if (isSeeking) return;
    state.currentTime = videoEl.currentTime;
    state.duration = videoEl.duration || 0;
    currentTimeEl.textContent = formatTime(state.currentTime);
    durationEl.textContent = formatTime(state.duration);
    if (state.duration) {
      const pct = (state.currentTime / state.duration) * 100;
      progressFill.style.width = pct + '%';
      progressHandle.style.left = pct + '%';
    }
    updateSubtitles();
  });
  videoEl.addEventListener('error', () => {
    if (currentItem && currentItem.remote && videoEl.src) toast("Couldn't stream this track. Try another result.");
  });
  videoEl.addEventListener('ended', playNext);
  videoEl.addEventListener('play', () => { state.isPlaying = true; updatePlayButton(); });
  videoEl.addEventListener('pause', () => { state.isPlaying = false; updatePlayButton(); });
  videoEl.addEventListener('loadedmetadata', () => {
    durationEl.textContent = formatTime(videoEl.duration);
  });

  // Keyboard
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    if (sync.on && !stage.classList.contains('hidden')) {
      if (e.code === 'Enter' || e.code === 'NumpadEnter') { e.preventDefault(); syncTap(); return; }
      if (e.code === 'Backspace') { e.preventDefault(); syncUndo(); return; }
    }
    switch (e.code) {
      case 'Space':
        e.preventDefault();
        togglePlay();
        break;
      case 'ArrowRight':
        videoEl.currentTime += 5;
        break;
      case 'ArrowLeft':
        videoEl.currentTime -= 5;
        break;
      case 'ArrowUp':
        e.preventDefault();
        state.volume = Math.min(1, state.volume + 0.05);
        volumeRange.value = state.volume;
        videoEl.volume = state.volume;
        break;
      case 'ArrowDown':
        e.preventDefault();
        state.volume = Math.max(0, state.volume - 0.05);
        volumeRange.value = state.volume;
        videoEl.volume = state.volume;
        break;
      case 'KeyN':
        playNext();
        break;
      case 'KeyP':
        playPrev();
        break;
      case 'KeyF':
        if (videoEl.src) { if (stage.classList.contains('hidden')) openStage(); else stage.classList.add('hidden'); }
        break;
      case 'KeyL':
        toggleLyricsStage();
        break;
      case 'Escape':
        if (sync.on) { cancelSync(false); break; }
        stage.classList.add('hidden');
        $('#eq-panel').classList.add('hidden');
        closeModal();
        break;
    }
  });

  // Menu bridge from Electron
  if (window.pulseAPI) {
    window.pulseAPI.onMenu('menu-add-files', addFilesDialog);
    window.pulseAPI.onMenu('menu-add-folder', addFolder);
    window.pulseAPI.onMenu('menu-clear-library', () => {
      if (confirm('Clear entire library?')) {
        state.library = [];
        state.queue = [];
        state.currentIndex = -1;
        state.playlists.forEach(pl => pl.trackIds = []);
        saveData();
        renderLibrary();
        renderQueue();
        renderPlaylists();
        updateStats();
        toast('Library cleared');
      }
    });
    window.pulseAPI.onMenu('menu-toggle-play', togglePlay);
    window.pulseAPI.onMenu('menu-next', playNext);
    window.pulseAPI.onMenu('menu-prev', playPrev);
  }

  // OS media keys / overlay controls
  if ('mediaSession' in navigator) {
    const set = (name, fn) => { try { navigator.mediaSession.setActionHandler(name, fn); } catch { /* unsupported */ } };
    set('play', () => { if (videoEl.paused) togglePlay(); });
    set('pause', () => { if (!videoEl.paused) togglePlay(); });
    set('previoustrack', playPrev);
    set('nexttrack', playNext);
  }

  // Init
  requestAnimationFrame(lyricsTick);
  applyTheme();
  renderEQBands();
  $('#eq-enabled').checked = state.eq.enabled;
  renderLibrary();
  renderQueue();
  renderPlaylists();
  updateStats();
  loadData();

  window.Pulse = { state, playItem, addPaths };
})();
