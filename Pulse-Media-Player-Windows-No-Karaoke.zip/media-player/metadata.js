// Dependency-free tag reader: title / artist / album / embedded artwork / embedded lyrics.
// Supports MP3 (ID3v2.2-2.4), FLAC, M4A/MP4 (iTunes atoms), OGG Vorbis & Opus.
// Falls back to cover.jpg / folder.jpg etc. in the same folder.
const fs = require('fs');
const path = require('path');

const MAX_TAG_BYTES = 40 * 1024 * 1024;

function readAt(fd, pos, len) {
  const buf = Buffer.alloc(len);
  const n = fs.readSync(fd, buf, 0, len, pos);
  return n < len ? buf.subarray(0, n) : buf;
}

// ---------- text helpers ----------
function decodeText(buf, enc) {
  if (!buf.length) return '';
  let s;
  if (enc === 1) {
    if (buf[0] === 0xff && buf[1] === 0xfe) s = buf.subarray(2).toString('utf16le');
    else if (buf[0] === 0xfe && buf[1] === 0xff) s = Buffer.from(buf.subarray(2)).swap16().toString('utf16le');
    else s = buf.toString('utf16le');
  } else if (enc === 2) {
    s = Buffer.from(buf).swap16().toString('utf16le');
  } else if (enc === 3) {
    s = buf.toString('utf8');
  } else {
    s = buf.toString('latin1');
  }
  return s.replace(/\u0000+$/, '');
}

// index of the terminator for the given encoding, or -1
function findTerm(buf, start, enc) {
  if (enc === 1 || enc === 2) {
    for (let i = start; i + 1 < buf.length; i += 2) {
      if (buf[i] === 0 && buf[i + 1] === 0) return i;
    }
    return -1;
  }
  return buf.indexOf(0, start);
}
const termLen = (enc) => (enc === 1 || enc === 2 ? 2 : 1);

function syncsafe(b, o) {
  return ((b[o] & 0x7f) << 21) | ((b[o + 1] & 0x7f) << 14) | ((b[o + 2] & 0x7f) << 7) | (b[o + 3] & 0x7f);
}

function unsync(buf) {
  const out = [];
  for (let i = 0; i < buf.length; i++) {
    out.push(buf[i]);
    if (buf[i] === 0xff && buf[i + 1] === 0x00) i++;
  }
  return Buffer.from(out);
}

function sniffMime(buf) {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf.length > 8 && buf.subarray(1, 4).toString('latin1') === 'PNG') return 'image/png';
  if (buf.length > 12 && buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  if (buf.length > 3 && buf.subarray(0, 3).toString('latin1') === 'GIF') return 'image/gif';
  if (buf.length > 2 && buf[0] === 0x42 && buf[1] === 0x4d) return 'image/bmp';
  return null;
}

function formatLrcTime(ms) {
  const total = Math.max(0, ms) / 1000;
  const m = Math.floor(total / 60);
  const s = total - m * 60;
  return `[${String(m).padStart(2, '0')}:${s.toFixed(2).padStart(5, '0')}]`;
}

// ---------- ID3v2 ----------
function parseID3(fd, result) {
  const head = readAt(fd, 0, 10);
  if (head.length < 10 || head.subarray(0, 3).toString('latin1') !== 'ID3') return 0;
  const ver = head[3];
  const flags = head[5];
  const size = syncsafe(head, 6);
  if (size > MAX_TAG_BYTES) return size + 10;
  let body = readAt(fd, 10, size);
  if (flags & 0x80 && ver < 4) body = unsync(body);

  let pos = 0;
  if (flags & 0x40 && body.length >= 4) {
    const ext = ver === 4 ? syncsafe(body, 0) : body.readUInt32BE(0) + 4;
    pos = ext;
  }

  const pics = [];
  while (pos + (ver === 2 ? 6 : 10) <= body.length) {
    let id, fsize, fflags = 0, hdr;
    if (ver === 2) {
      id = body.subarray(pos, pos + 3).toString('latin1');
      fsize = (body[pos + 3] << 16) | (body[pos + 4] << 8) | body[pos + 5];
      hdr = 6;
    } else {
      id = body.subarray(pos, pos + 4).toString('latin1');
      fsize = ver === 4 ? syncsafe(body, pos + 4) : body.readUInt32BE(pos + 4);
      fflags = body.readUInt16BE(pos + 8);
      hdr = 10;
    }
    if (!id || id.charCodeAt(0) === 0 || !/^[A-Z0-9]+$/.test(id)) break;
    if (fsize <= 0 || pos + hdr + fsize > body.length) break;
    let data = body.subarray(pos + hdr, pos + hdr + fsize);
    pos += hdr + fsize;

    if (ver === 4) {
      if (fflags & 0x0001) data = data.subarray(4);       // data length indicator
      if (fflags & 0x0002) data = unsync(data);           // per-frame unsync
    }
    if (!data.length) continue;

    try {
      if (id === 'TIT2' || id === 'TT2') result.title = result.title || decodeText(data.subarray(1), data[0]);
      else if (id === 'TPE1' || id === 'TP1') result.artist = result.artist || decodeText(data.subarray(1), data[0]).split('\u0000')[0];
      else if (id === 'TALB' || id === 'TAL') result.album = result.album || decodeText(data.subarray(1), data[0]);
      else if (id === 'USLT' || id === 'ULT') {
        const enc = data[0];
        let p = 4; // enc + 3 byte lang
        const t = findTerm(data, p, enc);
        if (t !== -1) {
          const text = decodeText(data.subarray(t + termLen(enc)), enc);
          if (text.trim()) result.lyricsPlain = result.lyricsPlain || text;
        }
      } else if (id === 'SYLT') {
        const enc = data[0];
        const tsFormat = data[4];
        let p = 6;
        const t = findTerm(data, p, enc);
        if (t !== -1 && tsFormat === 2) { // milliseconds only
          p = t + termLen(enc);
          const lines = [];
          while (p < data.length) {
            const e = findTerm(data, p, enc);
            if (e === -1 || e + termLen(enc) + 4 > data.length) break;
            const text = decodeText(data.subarray(p, e), enc).replace(/^\n/, '');
            const ts = data.readUInt32BE(e + termLen(enc));
            lines.push(`${formatLrcTime(ts)}${text}`);
            p = e + termLen(enc) + 4;
          }
          if (lines.length) result.lyricsSynced = result.lyricsSynced || lines.join('\n');
        }
      } else if (id === 'APIC' || id === 'PIC') {
        const enc = data[0];
        let p = 1;
        if (id === 'PIC') p += 3;
        else {
          const m = data.indexOf(0, p);
          if (m === -1) continue;
          p = m + 1;
        }
        const picType = data[p];
        p += 1;
        const d = findTerm(data, p, enc);
        if (d === -1) continue;
        p = d + termLen(enc);
        const img = data.subarray(p);
        pics.push({ type: picType, data: img });
      }
    } catch { /* skip bad frame */ }
  }

  if (pics.length) {
    const front = pics.find(p => p.type === 3) || pics.find(p => p.type === 0) || pics[0];
    if (front.data.length) result.art = front.data;
  }
  return size + 10;
}

// ---------- Vorbis comments + FLAC picture ----------
function parsePictureBlock(buf) {
  try {
    let p = 4;                                  // picture type
    const mimeLen = buf.readUInt32BE(p); p += 4 + mimeLen;
    const descLen = buf.readUInt32BE(p); p += 4 + descLen;
    p += 16;                                    // w,h,depth,colors
    const len = buf.readUInt32BE(p); p += 4;
    return buf.subarray(p, p + len);
  } catch { return null; }
}

function parseVorbisComment(buf, result) {
  try {
    let p = 0;
    const vlen = buf.readUInt32LE(p); p += 4 + vlen;
    const count = buf.readUInt32LE(p); p += 4;
    for (let i = 0; i < count && p + 4 <= buf.length; i++) {
      const len = buf.readUInt32LE(p); p += 4;
      const entry = buf.subarray(p, p + len).toString('utf8'); p += len;
      const eq = entry.indexOf('=');
      if (eq < 0) continue;
      const key = entry.slice(0, eq).toUpperCase();
      const val = entry.slice(eq + 1);
      if (key === 'TITLE') result.title = result.title || val;
      else if (key === 'ARTIST') result.artist = result.artist || val;
      else if (key === 'ALBUM') result.album = result.album || val;
      else if (key === 'LYRICS' || key === 'UNSYNCEDLYRICS' || key === 'SYNCEDLYRICS') {
        if (/\[\d+:\d+/.test(val)) result.lyricsSynced = result.lyricsSynced || val;
        else result.lyricsPlain = result.lyricsPlain || val;
      } else if (key === 'METADATA_BLOCK_PICTURE' && !result.art) {
        const img = parsePictureBlock(Buffer.from(val, 'base64'));
        if (img && img.length) result.art = img;
      }
    }
  } catch { /* ignore */ }
}

function parseFLAC(fd, offset, result) {
  let pos = offset + 4;
  for (let guard = 0; guard < 200; guard++) {
    const h = readAt(fd, pos, 4);
    if (h.length < 4) break;
    const last = !!(h[0] & 0x80);
    const type = h[0] & 0x7f;
    const len = (h[1] << 16) | (h[2] << 8) | h[3];
    pos += 4;
    if (len > MAX_TAG_BYTES) { pos += len; if (last) break; continue; }
    if (type === 4) parseVorbisComment(readAt(fd, pos, len), result);
    else if (type === 6 && !result.art) {
      const img = parsePictureBlock(readAt(fd, pos, len));
      if (img && img.length) result.art = img;
    }
    pos += len;
    if (last) break;
  }
}

// ---------- OGG (Vorbis / Opus) ----------
function parseOgg(fd, result) {
  const packets = [];
  let current = [];
  let pos = 0;
  const limit = MAX_TAG_BYTES;
  while (packets.length < 2 && pos < limit) {
    const h = readAt(fd, pos, 27);
    if (h.length < 27 || h.subarray(0, 4).toString('latin1') !== 'OggS') break;
    const nseg = h[26];
    const segTable = readAt(fd, pos + 27, nseg);
    let dataLen = 0;
    for (const s of segTable) dataLen += s;
    const data = readAt(fd, pos + 27 + nseg, dataLen);
    let off = 0;
    for (const s of segTable) {
      current.push(data.subarray(off, off + s));
      off += s;
      if (s < 255) { packets.push(Buffer.concat(current)); current = []; }
    }
    pos += 27 + nseg + dataLen;
  }
  const pkt = packets[1];
  if (!pkt) return;
  if (pkt.subarray(0, 8).toString('latin1') === 'OpusTags') parseVorbisComment(pkt.subarray(8), result);
  else if (pkt[0] === 3 && pkt.subarray(1, 7).toString('latin1') === 'vorbis') parseVorbisComment(pkt.subarray(7), result);
}

// ---------- MP4 / M4A ----------
function parseMP4(fd, result) {
  const stat = fs.fstatSync(fd);
  let pos = 0;
  let moov = null;
  while (pos + 8 <= stat.size) {
    const h = readAt(fd, pos, 16);
    let size = h.readUInt32BE(0);
    const type = h.subarray(4, 8).toString('latin1');
    let hdr = 8;
    if (size === 1) { size = Number(h.readBigUInt64BE(8)); hdr = 16; }
    else if (size === 0) size = stat.size - pos;
    if (size < hdr) break;
    if (type === 'moov') {
      if (size - hdr > MAX_TAG_BYTES) return;
      moov = readAt(fd, pos + hdr, size - hdr);
      break;
    }
    pos += size;
  }
  if (!moov) return;

  const children = (buf, start, end) => {
    const out = [];
    let p = start;
    while (p + 8 <= end) {
      let size = buf.readUInt32BE(p);
      const type = buf.subarray(p + 4, p + 8).toString('latin1');
      if (size < 8 || p + size > end) break;
      out.push({ type, start: p + 8, end: p + size });
      p += size;
    }
    return out;
  };

  const udta = children(moov, 0, moov.length).find(b => b.type === 'udta');
  if (!udta) return;
  const meta = children(moov, udta.start, udta.end).find(b => b.type === 'meta');
  if (!meta) return;
  const ilst = children(moov, meta.start + 4, meta.end).find(b => b.type === 'ilst');
  if (!ilst) return;

  for (const item of children(moov, ilst.start, ilst.end)) {
    const d = children(moov, item.start, item.end).find(b => b.type === 'data');
    if (!d) continue;
    const payload = moov.subarray(d.start + 8, d.end);
    const key = item.type;
    if (key === '\u00a9nam') result.title = result.title || payload.toString('utf8');
    else if (key === '\u00a9ART') result.artist = result.artist || payload.toString('utf8');
    else if (key === 'aART') result.artist = result.artist || payload.toString('utf8');
    else if (key === '\u00a9alb') result.album = result.album || payload.toString('utf8');
    else if (key === '\u00a9lyr') {
      const val = payload.toString('utf8');
      if (/\[\d+:\d+/.test(val)) result.lyricsSynced = result.lyricsSynced || val;
      else result.lyricsPlain = result.lyricsPlain || val;
    } else if (key === 'covr' && !result.art) result.art = Buffer.from(payload);
  }
}

// ---------- folder fallbacks ----------
const COVER_NAMES = ['cover', 'folder', 'front', 'album', 'albumart', 'albumartsmall', 'artwork', 'thumb'];
const IMG_EXTS = ['.jpg', '.jpeg', '.png', '.webp', '.bmp'];

function findFolderArt(filePath) {
  try {
    const dir = path.dirname(filePath);
    const base = path.basename(filePath, path.extname(filePath)).toLowerCase();
    const files = fs.readdirSync(dir);
    const lower = files.map(f => ({ f, l: f.toLowerCase() }));
    // same-name image first, then common cover names
    const candidates = [];
    for (const ext of IMG_EXTS) candidates.push(base + ext);
    for (const n of COVER_NAMES) for (const ext of IMG_EXTS) candidates.push(n + ext);
    for (const c of candidates) {
      const hit = lower.find(x => x.l === c);
      if (hit) {
        const buf = fs.readFileSync(path.join(dir, hit.f));
        if (buf.length) return buf;
      }
    }
  } catch { /* ignore */ }
  return null;
}

function findSidecarLyrics(filePath) {
  const noExt = filePath.slice(0, filePath.length - path.extname(filePath).length);
  for (const ext of ['.lrc', '.LRC', '.Lrc']) {
    try {
      if (fs.existsSync(noExt + ext)) return fs.readFileSync(noExt + ext, 'utf8');
    } catch { /* ignore */ }
  }
  return null;
}

// ---------- public ----------
function readMetadata(filePath) {
  const result = {};
  let fd;
  try {
    fd = fs.openSync(filePath, 'r');
    const ext = path.extname(filePath).toLowerCase();
    let offset = 0;
    const magic = readAt(fd, 0, 12);
    if (magic.subarray(0, 3).toString('latin1') === 'ID3') offset = parseID3(fd, result);

    const afterID3 = offset ? readAt(fd, offset, 4) : magic;
    if (afterID3.subarray(0, 4).toString('latin1') === 'fLaC') parseFLAC(fd, offset, result);
    else if (magic.subarray(0, 4).toString('latin1') === 'OggS') parseOgg(fd, result);
    else if (magic.subarray(4, 8).toString('latin1') === 'ftyp' || ['.m4a', '.mp4', '.m4v', '.aac', '.mov'].includes(ext) && magic.subarray(4, 8).toString('latin1') === 'ftyp') parseMP4(fd, result);
  } catch (e) {
    // unreadable / unsupported — fall through to fallbacks
  } finally {
    if (fd !== undefined) { try { fs.closeSync(fd); } catch { /* ignore */ } }
  }

  if (!result.art || !result.art.length) {
    const folderArt = findFolderArt(filePath);
    if (folderArt) result.art = folderArt;
  }
  if (result.art) result.artMime = sniffMime(result.art) || 'image/jpeg';

  const sidecar = findSidecarLyrics(filePath);
  result.lyrics = sidecar || result.lyricsSynced || result.lyricsPlain || null;
  result.lyricsSource = sidecar ? 'file' : (result.lyrics ? 'embedded' : null);
  delete result.lyricsSynced;
  delete result.lyricsPlain;
  return result;
}

module.exports = { readMetadata };
