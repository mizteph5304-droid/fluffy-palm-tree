@echo off
setlocal
cd /d "%~dp0"
title Pulse Media Player
where node >nul 2>nul || (echo Node.js is not installed. Install Node.js 24 LTS from https://nodejs.org/ and try again.& pause & exit /b 1)
where npm >nul 2>nul || (echo npm was not found. Reinstall Node.js 24 LTS and reopen this window.& pause & exit /b 1)
echo.
echo ========================================
echo       Pulse Media Player - Start
echo ========================================
echo.
node --version
if not exist "node_modules\electron\dist\electron.exe" (
  echo Installing Pulse dependencies and Electron. This may take a few minutes...
  set npm_config_ignore_scripts=false
  call npm install --include=dev --foreground-scripts --no-audit --no-fund
  if errorlevel 1 goto install_error
)
if not exist "node_modules\electron\dist\electron.exe" (
  echo Electron's setup script did not finish. Trying its installer directly...
  node node_modules\electron\install.js
  if errorlevel 1 goto install_error
)
if not exist "node_modules\electron\dist\electron.exe" goto install_error
echo.
echo Starting Pulse...
call npm start
if errorlevel 1 echo Pulse closed with an error. Please copy the messages above.
echo.
pause
exit /b 0
:install_error
echo.
echo Electron could not be downloaded or installed.
echo Check your internet connection, VPN/proxy, and antivirus quarantine.
echo Keep this window open and copy the full error messages if it fails again.
pause
exit /b 1
