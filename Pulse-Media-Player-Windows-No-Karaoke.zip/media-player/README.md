# Pulse — Local Media Player

A clean, modern local media player inspired by **VLC** with a UI that mixes **Apple** (minimal, refined) and **Spotify** (dark theme, green accent, bottom player bar).

Runs as a native **Windows** desktop app via Electron (also works on macOS / Linux).

## Features

- **Local files only** — Add Files or Add Folder (recursive scan)
- **Persistent library** — paths saved between sessions
- **Playlists** — create, add tracks, play entire playlist
- **Queue** with next / previous
- **10-band Equalizer** with presets (Flat, Bass, Treble, Vocal, Rock)
- **Subtitle support** — load `.srt` files while watching video
- **Library view** with search + sort (Recent / Name / Type)
- **Fullscreen stage** for video or large audio art
- **Keyboard shortcuts**:
  - `Space` — play/pause
  - `←` / `→` — seek ±5s
  - `↑` / `↓` — volume
  - `N` / `P` — next / previous
  - `F` — toggle stage
  - `Esc` — close overlays
- Light / dark theme
- Context menu on cards
- Native menus (File, Playback, View)

## Supported formats

Depends on Chromium (Electron):

- **Audio**: MP3, WAV, FLAC, AAC, OGG, M4A, Opus…
- **Video**: MP4, WebM, MOV, MKV (partial), etc.

## Run on Windows (development)

### Prerequisites
- [Node.js](https://nodejs.org/) 18+ (includes npm)

### Steps

```bash
cd media-player
npm install
npm start
```

That launches the Electron app.

### Build a Windows installer / portable exe

```bash
npm run build:win
```

Output appears in the `dist/` folder:
- `Pulse Setup x.x.x.exe` — NSIS installer
- `Pulse x.x.x.exe` — portable version (no install needed)

You can also run only the portable target:

```bash
npm run build:win-portable
```

## Project structure

```
media-player/
├── package.json          # Electron + electron-builder config
├── main.js               # Electron main process
├── preload.js            # Safe IPC bridge
├── index.html
├── css/styles.css
├── js/app.js
├── assets/               # (optional icon)
└── README.md
```

## Notes

- Library data is stored in the Electron userData folder (`pulse-data.json`).
- Missing files are automatically pruned on startup.
- Equalizer uses the Web Audio API (works for both audio and video).
- For a custom app icon, place `icon.ico` in `assets/` before building.

## License

MIT
