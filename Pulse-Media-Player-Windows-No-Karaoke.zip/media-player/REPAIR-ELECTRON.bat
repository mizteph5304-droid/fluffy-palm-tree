@echo off
setlocal
cd /d "%~dp0"
title Repair Pulse Electron
where node >nul 2>nul || (echo Install Node.js 24 LTS first.& pause & exit /b 1)
if exist "node_modules\electron" rmdir /s /q "node_modules\electron"
set npm_config_ignore_scripts=false
call npm install --include=dev --foreground-scripts --no-audit --no-fund
if errorlevel 1 goto failed
if not exist "node_modules\electron\dist\electron.exe" node node_modules/electron/install.js
if not exist "node_modules\electron\dist\electron.exe" goto failed
echo Electron is installed. Run START-HERE.bat to launch Pulse.
pause
exit /b 0
:failed
echo Electron repair failed. Check the network/proxy/antivirus messages above.
pause
exit /b 1
