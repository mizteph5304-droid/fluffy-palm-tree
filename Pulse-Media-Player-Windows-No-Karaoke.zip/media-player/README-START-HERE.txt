PULSE MEDIA PLAYER — WINDOWS SOURCE BUILD

This version keeps the standard music player and its regular lyrics panel.
The experimental karaoke mode and AI vocal-separation components are not included.

RECOMMENDED SETUP
- Windows 10 or 11 (64-bit)
- Node.js 24 LTS: https://nodejs.org/
- Internet access for the first dependency/Electron download

TO RUN
1. Extract the ZIP to a normal folder (not inside the ZIP).
2. Double-click START-HERE.bat.
3. Leave the terminal window open while Pulse starts.

TO BUILD A WINDOWS INSTALLER
1. Double-click BUILD-WINDOWS.bat.
2. When complete, find the installer and portable build in the dist folder.

If Electron fails to install, run REPAIR-ELECTRON.bat, then START-HERE.bat.
A blocked network download, VPN/proxy, or antivirus quarantine can prevent Electron
from installing. Keep the terminal open and save the full error output if it fails.

Your music files are not included in this source package and are not deleted by
these setup scripts.
